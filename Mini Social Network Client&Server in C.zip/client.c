#include "client.h"

int main(int argc, char *argv[])
{
    struct sockaddr_in s_addr;
    int fd, dim, ret, s_port;
    char msg[BUFSIZE];
    char username[64];
    char password[64];
    char cip[280];
    char userToServer[64];
    userToServer[0] = 0;
    
    if (argc < 3) {
        printf("usage : client <server IP> <port> \n");
        exit(-1);
    }
    
    printf("Benvenuto in Robin Blogging\n");
    
    for(;;) {
        s_port = atoi(argv[2]);

        fd = socket (AF_INET, SOCK_STREAM, 0);

        memset(&s_addr, 0, sizeof(s_addr));
        s_addr.sin_family = AF_INET;
        s_addr.sin_port = htons (s_port);
        inet_pton(AF_INET, argv[1], &s_addr.sin_addr);

        if (connect(fd, (struct sockaddr*)&s_addr,
                        sizeof(struct sockaddr_in)) < 0) {
            perror("connect()");
            exit (-1);
        }
        memset(msg, 0, sizeof(msg));
        memset(username, 0, sizeof(username));
        memset(password, 0, sizeof(password));
        printf ("> ");
        fgets(msg, sizeof(msg), stdin);	
        msg [strcspn(msg, "\r\n")] = 0;	                                                                 //per gestire del tasto invio (return) a vuoto
        int isExit = strcmp(msg,"quit");
        
        if((strstr(msg,"register") > 0 || strstr(msg, "login") > 0) && userToServer[0] == 0) {			 //returns substring
            printf ("Inserisci l'username\n");
            fgets(username, sizeof(username), stdin);
            username [strcspn(username, "\r\n")] = 0;
            printf("Inserisci la password\n");
            fgets(password, sizeof(password), stdin);
            password [strcspn(password, "\r\n")] = 0;
            strcat(msg, "-");                                   //allega al messaggio queste cose
            strcat(msg, username);
            strcat(msg, "-");
            strcat(msg, password);
        }
        if(strstr(msg,"cip") > 0) {
            printf("Inserisci il cip\n");
            fgets(cip, sizeof(cip), stdin);
            cip [strcspn(cip, "\r\n")] = 0;
            strcat(msg,"-");
            strcat(msg,cip);
        }
        
        msg [strcspn(msg, "\r\n")] = 0;                         //per gestire del tasto invio (return) a vuoto   
        
        if(userToServer[0] != 0) {
            strcat(msg,"&");                                    //serve per inviare il comando al server (mi fa da delimitatore di carattere per la funzione manage_response in server.c)
            strcat(msg,userToServer);
        }

        dim = htonl(strlen(msg));
        ret = send(fd, (void *) &dim, sizeof(dim), 0);
        if (ret < 0 || ret < sizeof(dim)) {
            perror("send(len)");
            exit (-1);
        }
        ret = send(fd, (void*)msg, strlen(msg), 0);
        if (ret < 0 || ret < strlen(msg)) {
            perror("send(msg)");
            exit (-1);
        }

        ret = recv(fd, (void*)&dim, sizeof(dim), MSG_WAITALL);
        if (ret < 0 || ret < sizeof(dim)) {
            perror("recv(len)");
            exit (-1);
        }
        dim = ntohl(dim);
        memset(msg, 0, sizeof(msg));
        memset(username, 0, sizeof(username));
        memset(password, 0, sizeof(password));
        ret = recv(fd, (void*) msg, sizeof(msg), MSG_WAITALL);
        if (ret < 0) {
            perror("recv(msg)");
            exit (-1);
        }
        
        // QUA GESTISCO LA RESPONSE DEL SERVER
        printf("Server > %s\n", msg);
        
        if(strstr(msg,"Benvenuto") != NULL) {           //quando arriva questa sottostringa, significa che sono loggato, quindi scrivo su userToServer[0]
            char *payload = strtok(msg, " ");
            int k=0;
            while(payload != NULL) {
                payload = strtok(NULL, " ");
                //printf("payload %s\n",payload);
                if(k == 0) {
                    strcpy(userToServer,payload);       //userToServer[0]
                    break;
                }
                k++;
            }
        }
        
        if(isExit == 0) {
            break;
        }
    }
    close(fd);
    return 0;
}
