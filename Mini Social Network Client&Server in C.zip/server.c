#include "server.h"

	
/* per-thread identifiers */
static pthread_t tid[NUM_THREADS];

/* per-thread event semaphores */
static sem_t evsem[NUM_THREADS];

/* map of busy threads */
static int busy[NUM_THREADS];

 /* per-thread current connection socket */   
static int fds[NUM_THREADS];

/* global lock for shared data structures */
static pthread_mutex_t glock, reg, log, cip;
static pthread_mutexattr_t attribute;

/* resource semaphore to wait for free threads */
static sem_t free_threads;


struct utente {
    int id;
    int isLogged;
    int follow[NUM_USERS];
    int followed;
    int followerNumber;
    char username[64];
    char password[64];//
    struct cip cip[NUM_CIP];
    struct hashtags hash[NUM_HASHTAGS];
};

struct utente u[NUM_USERS];

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                 SOTTO CI SONO FUNZIONI SERVER                                                                //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static char char_for_salt() {                                   //criptazione
	int r, t1, t2, t3, tot;

	// Genero i caratteri del salt in modo tale che 
    //appartengano a uno degli
	// intervalli previsti: ./0..9   a..z   A..Z
	t1 = '9' - '.' + 1;
	t2 = 'z' - 'a' + 1;
	t3 = 'Z' - 'A' + 1;
	tot = t1 + t2 + t3;

	r = rand();
	r = r % tot;
	if(r < t1) return r + '.';
	if(r < t1 + t2) return r - t1 + 'A';
	return r - t1 - t2 + 'a';
}

static void create_salt(char salt[]) {                          //criptazione
	salt[0] = char_for_salt();
	salt[1] = char_for_salt();
	//printf("Salt: %c%c\n", salt[0], salt[1]);
}

static int get_hashtag(char **p, char buf[], size_t max){       //trova l'hashtag
    char *q;
    if (*p == NULL || **p == '\0') return 0;
    q = strchr(*p, '#');
    while (q && is_valid(q[1], 0) == 0) {
        q = strchr(q + 1, '#');
    }
    if (q) {
        size_t n = 0;
        q++;                    /* skip hash sign*/
        while (n + 1 < max && is_valid(*q, 1)) {
            buf[n++] = *q++;
        }
        if (max) buf[n] = '\0'; /* terminate buffer*/
        *p = q;                 /* remember position*/
        return 1;               /* hashtag found*/
    }
    return 0;                   /* nothing found*/
}

static int is_valid(int c, int num_allowed) {                   //funzione usata da get_hashtag
    if ('A' <= c && c <= 'Z') return 1;
    if ('a' <= c && c <= 'z') return 1;
    if ('0' <= c && c <= '9') return num_allowed;
    if (c == '_') return 1;
    return 0;
}


static int get_free_hash_index(int userIndex) {                 //indice degli hashtag
    int emptyIndex = -1;
	int i;
	for (i=0; i < NUM_HASHTAGS; i++) {
		if(u[userIndex].hash[i].id < 0) {
			emptyIndex = i;
			break;									
		}
	}
	return emptyIndex;
}

static int get_free_user_index() {					            //restituisce prima posizione nel vettore disponibile
	int emptyIndex = -1;
	int i;
	for (i=0; i < NUM_USERS; i++) {
		if(!u[i].id) {
			emptyIndex = i;
			break;									
		}
	}
	return emptyIndex;
}

static int get_user_index(char * username) {
    //printf("USER TO FIND %s\n",username);				        //numero utente associato
    int userIndex = -1;
    if(username == NULL) return userIndex;
    int i;
    for (i=0; i < NUM_USERS; i++) {
        if(strcmp(u[i].username,username) == 0) {
            userIndex = i;
            break;
        }
    } 
    return userIndex;
}

static int get_free_follower_index(int userIndex) {	            //restituisce prima posizione nel vettore disponibile
   int emptyIndex = -1;
    int i;
    for (i=0; i < NUM_USERS; i++) {
        if(u[userIndex].follow[i] == -1) {				
            emptyIndex = i;
            
            break;
        }
    }
    //printf("---EMPTY INDEX %d---", emptyIndex);
    return emptyIndex;
}

static int get_free_cip_index(int userIndex) {		            //restituisce prima posizione nel vettore disponibile
    int emptyIndex = -1;
    int i;
    for (i=0; i < NUM_CIP; i++) {
        if(!u[userIndex].cip[i].time) {
            emptyIndex = i;
            break;
        }
    }	
    return emptyIndex;
}

static int valueinarray(int val, int arr[]) {		             //trova corrispondenza
    int i;
    for(i = 0; i < NUM_USERS; i++) {
        if(arr[i] == val)
            return 1;
    }
    return 0;
}

static void init_follow_array(int userIndex) {		              //inizializza array a -1
	int i;
	for(i=0; i < NUM_USERS; i++) {
		u[userIndex].follow[i] = -1;   
	}
}

static void init_hash_struct_id(int userIndex) {		          //inizializza array a -1
	int i;
	for(i=0; i < NUM_HASHTAGS; i++) {
		u[userIndex].hash[i].id = -1;
        u[userIndex].hash[i].counter = 0;
	}
}

static void clean_userData(int userIndex) {				         //"dealloca" l'utente senza eliminare il suo contenuto
    if(userIndex > -1) {
        u[userIndex].isLogged = -1;
    }
}

static int check_loggedUser(int index) {                         //verifica se l'utente è loggato
    if(index == -1) return -1;
    int i;
    int temp = u[index].id;
    for(i=0;i < NUM_USERS; i++){
        if(u[i].id == temp){
            //return u[index].isLogged;
            return 1;
        }
    }
    //return u[index].isLogged;
    return 0;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                 SOTTO CI SONO FUNZIONI UTENTE                                                                //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static char* print_help() {
    return "*Comandi disponibili*:\nhelp\t\t\t-->mostra l'elenco dei comandi disponibili\nregister\t\t-->registrazione al sistema\nlogin\t\t\t-->entra nel sistema\nfollow altro_utente\t-->diventa seguace di altro_utente\ncip\t\t\t-->nuovo cip\nhome\t\t\t-->visualizza la mia home page\nquit\t\t\t-->esce dal sistema";
}

static char * execute_follow(char * msg, int index) {		//comando "segui"
    char * username;
    char * payload = strtok(msg, " ");						//prende token e mette \n
    int k = 0;
    while(payload != NULL) {
        payload = strtok(NULL, " ");
        //printf("payload %s\n",payload);
        if(k == 0) {
            username = payload;
            break;
        }
        k++;
    }
    //printf("USERNAME DA SEGUIRE %s",username);
    if(username == NULL) return "*Follow usage: follow -altro_utente-*";
    if(strcmp(username,u[index].username) == 0) return "*Non puoi seguire te stesso*";
    int i;
    for(i=0; i < NUM_USERS; i++) {
        //printf("USERNAME DI CONFRONTO %s",u[i].username);
        if(strcmp(u[i].username,username) == 0) {						//se lo trova
            int alreadyFollowed = valueinarray(i, u[index].follow);
            //printf("VALUE IN ARRAY RESULT %d\n",alreadyFollowed);
            if(alreadyFollowed)
                return "*Segui già questo utente*";
            u[index].followed++;
            int indexFollow = get_free_follower_index(index);
            if(indexFollow == -1) return "*Non puoi più seguire nessuno*";
            u[index].follow[indexFollow] = i;
            //printf("SEGUI L'UTENTE CON ID %d IN POSIZIONE %d\n",u[index].follow[indexFollow], indexFollow);
            u[i].followerNumber++;
            char res[BUFSIZE];
            sprintf(res, "*Ora segui l'utente %s*",username);				
            char * response = malloc(sizeof(res)+1);
            strcpy(response,res);
            return response;
        }
    }
    return "*Utente da seguire non trovato*";
}

static void extract_hashtag(struct cip c, int userIndex) {              //estrae l'hashtag e lo inserisce in struttura
    char *tweet = c.text;
    char tag[NUM_CHARACTERS]; 
    while(get_hashtag(&tweet, tag, sizeof(tag))) {
        //printf("TAG TROVATO: %s\n",tag);
        int i;
        int found=0;
        for(i=0; i < NUM_HASHTAGS; i++) {
            if(u[userIndex].hash[i].id > -1 && strcmp(u[userIndex].hash[i].text,tag) == 0) {
               found = 1;
               u[userIndex].hash[i].counter++;
               //printf("TROVATO HASH GIA PRESENTE%s\n",u[userIndex].hash[i].text);
            }
        }
        if(!found) {
            int hashIndex = get_free_hash_index(userIndex);
            if(hashIndex > -1) {
                strcpy(u[userIndex].hash[hashIndex].text,tag);
                u[userIndex].hash[hashIndex].id = 1;
                u[userIndex].hash[hashIndex].counter++;
                //printf("AGGIUNTO NUOVO HASH %s ALL ID %d\n",u[userIndex].hash[hashIndex].text, hashIndex);
            }
        }
    }
}

static char * build_home(int index) {				                   //mostra home utente: vengono eseguiti i sort e le operazioni sul tempo su cip e hashtags usando variabili temporanee
    time_t currentTime = time(NULL);
    int currentTimeCasted = (int) currentTime;
    char follower[BUFSIZE];
    int followerNumber = u[index].followerNumber;
    
    int PRINT_CIP_LENGTH = NUM_CHARACTERS+20+512+3+2+1;
    int PRINT_HASH_LENGHT = 10+(NUM_CHARACTERS*NUM_HASHTAGS)+(5*NUM_HASHTAGS)+1;
    int TOTAL_CIP = NUM_CIP*NUM_USERS;
    int timeMinusHour= currentTimeCasted-3600;                         //3600 seconds = 1 hour
    int timeMinus24hours = currentTimeCasted-86400;                    //86400 = one day
    int i=0, j=0;
    
    sprintf(follower, "\n*********\nHome di: %s\n\nHai %d seguaci \n\n",u[index].username, followerNumber);
    
    init_hash_struct_id(index);
    //struct cip cip_from_follower[TOTAL_CIP];
    //struct hashtags hashtag_from_follower[TOTAL_CIP];
    struct cip *cip_from_follower = malloc(TOTAL_CIP*sizeof(struct cip));
    struct hashtags *hashtag_from_follower = malloc(TOTAL_CIP*sizeof(struct cip));;

    for(i=0; i < TOTAL_CIP; i++) {
        cip_from_follower[i].time = -1;
        memset(cip_from_follower[i].text,     '\0', NUM_CHARACTERS*sizeof(char));
        memset(cip_from_follower[i].username, '\0', 32*sizeof(char));
        memset(hashtag_from_follower[i].text, '\0', NUM_CHARACTERS*sizeof(char));
        hashtag_from_follower[i].counter = 0;
        hashtag_from_follower[i].id = -1;
    }
    
    // RACCOLGO TUTTI I CIP DEGLI UTENTI CHE SEGUO 
    for(i=0; i < NUM_USERS; i++) {
        int followId = u[index].follow[i];
        int k;
        //printf("FOLLOW ID: %d\n",followId);
        if(followId > -1) {
            for(k=0; k < NUM_CIP; k++) {
                if(strlen(u[followId].cip[k].text) > 0 && u[followId].cip[k].time > timeMinus24hours) {         //max 24 ore
                    cip_from_follower[j] = u[followId].cip[k];
                    //printf("CIP TIME FOUND %s\n",cip_from_follower[j].timeLabel);
                    //printf("CIP MSG FOUND %s\n",cip_from_follower[j].text);
                    extract_hashtag(cip_from_follower[j], index);
                }
                j++;
            }
        }
    }
    j=0;
    
    /*
    for(y=0; y < TOTAL_CIP; y++){
        if(strlen(cip_from_follower[y].text) > 0) 
            printf("%s %s - ",  cip_from_follower[y].username, cip_from_follower[y].text); 
    }
    printf("\n\n");
    //legacy
    char * allcips = malloc(PRINT_CIP_LENGTH);
    int y;
    int addCip=0;
    for(y=0; y < TOTAL_CIP; y++) {
        if(cip_from_follower[y].time > 0 && strlen(cip_from_follower[y].timeLabel) > 0 && strlen(cip_from_follower[y].username) > 0 && strlen(cip_from_follower[y].text) > 0) {
            printf("METTO ADD CIP AD 1\n");
            addCip = 1;
            char tempString[PRINT_CIP_LENGTH];
            sprintf(tempString,"%s %s %s\n",cip_from_follower[y].timeLabel,cip_from_follower[y].username,cip_from_follower[y].text);
            //printf("AGGREGO IL CIP %s\n",tempString);
            if(y != 0) {
                allcips = realloc(allcips,sizeof(allcips) + sizeof(tempString) +1);
                strcat(allcips,tempString);
            } else {
                strcpy(allcips,tempString);
            }
            //printf("CIP AGGREGATO %s\n",allcips);
        }
    }
    */
    
    //ORDINAMENTO CIPS
    char * allcips = malloc(PRINT_CIP_LENGTH*sizeof(char));
    int addCip=0;
    for(i=0; i < TOTAL_CIP; i++) {
        for(j=0; j < TOTAL_CIP; j++){
            //togliere tutte le condizioni tranne che text, Ã¨ sufficiente
            if(cip_from_follower[i].time > 0 && strlen(cip_from_follower[i].timeLabel) > 0 && strlen(cip_from_follower[i].username) > 0 && strlen(cip_from_follower[i].text) > 0) {
                addCip = 1;
                if(cip_from_follower[i].time > cip_from_follower[j].time){
                    struct cip cip_from_follower_temp;
                    cip_from_follower_temp = cip_from_follower[i];
                    cip_from_follower[i] = cip_from_follower[j];
                    cip_from_follower[j] = cip_from_follower_temp;
                }
            }
        }
    }
    //STAMPA CIPS SU CLIENT 
    for(i=0; i < NUM_CIP; i++){
        if(strlen(cip_from_follower[i].text) > 0 && (cip_from_follower[i].time > timeMinusHour)){           //max un'ora
            char tempString[PRINT_CIP_LENGTH];
            sprintf(tempString,"Alle %s, %s twitta -> %s\n",cip_from_follower[i].timeLabel,cip_from_follower[i].username,cip_from_follower[i].text);
            allcips = realloc(allcips,sizeof(allcips) + sizeof(tempString) +1);
            strcat(allcips,tempString);
        }
    }
    
    //legacy
    /*
    int PRINT_HASH_LENGHT = 10+(280*100)+(5*100)+1;
    char * allhash = malloc(PRINT_HASH_LENGHT);
    int x;
    int addHash=0;
    for(x=0; x < 100; x++) {
        if(u[index].hash[x].id > -1) {
            addHash=1;
            char tempHash[PRINT_HASH_LENGHT];
            sprintf(tempHash, "(%d) %s\n", u[index].hash[x].counter, u[index].hash[x].text);
            if(x != 0) {
                allhash = realloc(allhash,sizeof(allhash) + sizeof(tempHash) +1);
            } else {
                strcpy(allhash,"Hashtags:\n");
            }
            strcat(allhash,tempHash);
        }
    }
    */
    
    char * allhash = malloc(PRINT_HASH_LENGHT);
    j=0;
    int addHash=0;
    //COPIA IN VAR TEMPORANEA HASHTAGS
    for(i=0; i < NUM_HASHTAGS; i++){
        if(u[index].hash[i].id > -1 && strlen(u[index].hash[i].text) > 0){
            hashtag_from_follower[j] = u[index].hash[i];
            j++;
        }
    }
    //ORDINAMENTO HASHTAGS
    for(i=0; i < NUM_HASHTAGS; i++) {
        for(j=0; j < NUM_HASHTAGS; j++){
            if(hashtag_from_follower[i].id > -1) {
                addHash=1;
                if(hashtag_from_follower[i].counter > hashtag_from_follower[j].counter){
                    struct hashtags hashtags_temp;
                    hashtags_temp = hashtag_from_follower[i];
                    hashtag_from_follower[i] = hashtag_from_follower[j];
                    hashtag_from_follower[j] = hashtags_temp;
                }
            }
        }      
    }
    //STAMPA SU CLIENT HASHTAGS
    for(i=0; i < 10; i++){                                                                                      //solo i primi dieci hashtags (NUM_HASHTAGS per scorrerli tutti)
        //printf("%s: %d\n",hashtag_from_follower[i].text, hashtag_from_follower[i].time);
        if(strlen(hashtag_from_follower[i].text) > 0 && hashtag_from_follower[i].counter > 0 ){                 //fino a 24 ore prima (fatto precedentemente)
            char tempHash[PRINT_HASH_LENGHT];
            sprintf(tempHash, "(%d) -> %s\n", hashtag_from_follower[i].counter, hashtag_from_follower[i].text);
            if(i != 0) {
                allhash = realloc(allhash,sizeof(allhash) + sizeof(tempHash) +1);
            } else {
                strcpy(allhash,"\nHashtags di tendenza delle ultime 24 ore:\n\n");
            }
            strcat(allhash,tempHash);
        }
    }
    
    strcat(allhash,"*********\n");
    char * response = malloc(sizeof(follower)+sizeof(allcips)+sizeof(allhash)+1);
    strcpy(response,follower);
    if(addCip) {
        strcat(response,allcips);
    }
    if(addHash && strlen(allhash) > 0) {
        strcat(response,allhash);   
    }
    
    free(cip_from_follower);
    free(hashtag_from_follower);
    free(allcips);
    free(allhash);
    return response;
}

static char* manage_cip(char* msg,int userIndex) {                                                      //twitta
    pthread_mutex_lock(&cip);
    int cipId = get_free_cip_index(userIndex);
    //u[userIndex].cip[cipId].username = malloc(20*sizeof(char));
    if(cipId == -1) return "*Non puoi inserire CIP*";
    time_t currentTime = time(NULL);
    u[userIndex].cip[cipId].time = (int) currentTime;
    //printf("%d\n",u[userIndex].cip[cipId].time);
    strcpy(u[userIndex].cip[cipId].username,u[userIndex].username);
    strftime(u[userIndex].cip[cipId].timeLabel, 20, "%Y-%m-%d-%H:%M:%S", localtime(&currentTime)); 		//Format time as string
    printf("TIME LABEL %s\n",u[userIndex].cip[cipId].timeLabel);
    strncpy(u[userIndex].cip[cipId].text,msg,NUM_CHARACTERS);	
    pthread_mutex_unlock(&cip);
    return "*cip inserito*";
}

static char * register_user(char * username, char * password) {
    pthread_mutex_lock(&reg);
    char line[BUFSIZE];
    char userFd[64];
    char passFd[64];
    char passCrypt[512];
    // Salt
	char salt[2];
    
    FILE* ufd = fopen("user.txt", "a+");
    if(ufd == NULL) return "*Registrazione Fallita: errore di file*";
    while(fgets(line, sizeof(line), ufd)) {
        sscanf(line, "%s %s", userFd, passFd);
        if(strcmp(userFd,username) == 0) {
            fclose(ufd);
            pthread_mutex_unlock(&reg);
            return "*Registrazione Fallita2: utente già presente";
        }
    }
    
    int userIndex = get_user_index((char *) username);
    if(userIndex == -1) {
        userIndex = get_free_user_index();   
    }
    
    // Genero il salt
	create_salt(salt);
    // Cifro la password
	strncpy(passCrypt, crypt(password, salt), sizeof(passCrypt));
    
    snprintf(line, sizeof(line), "%s %s\n", username, passCrypt);
    ssize_t w = fwrite(line, 1, strlen(line), ufd);
    if(w != strlen(line)) {
        perror("fwrite");
        fclose(ufd);
        pthread_mutex_unlock(&reg);
        return "*Registrazione fallita*";
    }
    
    strcpy(u[userIndex].username,username);
    u[userIndex].id = 1;
    init_follow_array(userIndex);
    printf("USER ID ALLOCATO %d\n",userIndex);
    fclose(ufd);
    pthread_mutex_unlock(&reg);
    return "*Registazione avvenuta con successo*";
}

static char * login_user(char * username, char * password) {
    pthread_mutex_lock(&log);
    char line[BUFSIZE];
    char userFd[64];
    char passFd[64];
    char passCrypt[512];
    char salt[2];
    
    FILE* ufd = fopen("user.txt", "r");
    if(ufd == NULL) {
        pthread_mutex_unlock(&reg);
        return "*Login Fallito: errore di file*";
    }
    while(fgets(line, sizeof(line), ufd)) {
        sscanf(line, "%s %s", userFd, passFd);
        
		// Estraggo il salt
		salt[0] = passFd[0];
		salt[1] = passFd[1];
        
        strncpy(passCrypt, crypt(password, salt), sizeof(passCrypt));
        
        if(strcmp(userFd,username) == 0 && strcmp(passFd,passCrypt) == 0) {
            fclose(ufd);
            int userIndex = get_user_index(username);
            printf("LOGIN USER INDEX %d\n",userIndex);
            if(userIndex < 0) {
                pthread_mutex_unlock(&reg);
                return "*Login Fallito2*";
            }
            u[userIndex].isLogged = 1;
            char * loginmsg = malloc(523);
            strcpy(loginmsg, "Benvenuto ");
            strcat(loginmsg, u[userIndex].username);
            pthread_mutex_unlock(&log);
            return loginmsg;
        }
    }
    fclose(ufd);
    pthread_mutex_unlock(&log);
    return "*Login Fallito*";
}

//legacy
/*
static char* manage_response(char* msg,int index) {
    int userIndex = -1;
    if(strstr(msg,"&") != NULL) {
      msg = strtok(msg,"&");
      userIndex = get_user_index((char *) strtok(NULL,"&"));
      printf("USER REAL INDEX %d\n",userIndex);
    }
    if(strcmp(msg,"quit") == 0) {
        clean_userData(userIndex, index);						//"dealloca" l'utente senza eliminare il suo contenuto
        return "Grazie ed arrivederci";
    } else if(strcmp(msg,"help") == 0){
        return print_help();
    } else if(strcmp(msg,"register") == 0) {
        int free_index = get_free_user_index();
        if(free_index == -1) {
          clean_userData(-1, index);
          return "Non puoi più iscriverti";
        }
        p[index].registerProcess = 1;
        return "Inserire il nome utente e password separati da un trattino";
    } else if(p[index].registerProcess == 1) {
        int i = 0, k = 0, lenght = 0;
        lenght = strlen(msg);
        char *temp1, *temp2;
        temp1 = calloc(lenght,sizeof(char));temp2 = calloc(lenght,sizeof(char));
        while(msg[i] != '-'){
            temp1[i] = msg[i];
            i++;
        }
        printf("nome: %s\n", temp1);
        i++;
        while(i < lenght){
            temp2[k] = msg[i];
            i++;
            k++;
        }
        printf("pw: %s\n", temp2);
        strcpy(p[index].username,temp1);
        strcpy(p[index].password,temp2);
        free(temp1); free(temp2);
        p[index].registerProcess = 0;
        return register_user(index);
    } else if(strcmp(msg,"login") == 0) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged > 0) 
            return "Sei già loggato";
        p[index].loginProcess = 1;
        return "Inserisci il nome utente e la password separati da un trattino";
    } else if(p[index].loginProcess == 1) {
        int i = 0, k = 0, lenght = 0;
        lenght = strlen(msg);
        char *temp1, *temp2;
        temp1 = calloc(lenght,sizeof(char));temp2 = calloc(lenght,sizeof(char));
        while(msg[i] != '-'){
            temp1[i] = msg[i];
            i++;
        }
        printf("nome: %s\n", temp1);
        i++;
        while(i < lenght){
            temp2[k] = msg[i];
            i++;
            k++;
        }
        printf("pw: %s\n", temp2);
        strcpy(p[index].username,temp1);
        strcpy(p[index].password,temp2);
        free(temp1); free(temp2);
        p[index].loginProcess = 0;
        return login_user(index);
    } else if(strcmp(msg, "home") == 0) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged < 1) return "Devi eseguire il login";
        return build_home(userIndex);
    } else if(strcmp(msg, "cip") == 0) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged < 1) return "Devi eseguire il login";
        p[index].cipProcess = 1;
        return "Inserisci il cip";
    } else if(p[index].cipProcess == 1) {
        p[index].cipProcess = 0;
        return manage_cip(msg,userIndex);
    } else if(strstr(msg, "follow") != NULL) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged < 1) return "Devi eseguire il login";
        return execute_follow(msg,userIndex);
    } else {
        return "comando sconosciuto riprovare";
    }
}
*/

static char* manage_response(char* msg,int index) {
    int userIndex = -1;
    if(strstr(msg,"&") != NULL) {
      msg = strtok(msg,"&");
      userIndex = get_user_index((char *) strtok(NULL,"&"));
      //printf("USER REAL INDEX %d\n",userIndex);
    }
    if(strcmp(msg,"quit") == 0) {
        clean_userData(userIndex);						        //"dealloca" l'utente senza eliminare il suo contenuto
        return "*Grazie ed arrivederci*";
    } else if(strcmp(msg,"help") == 0){
        return print_help();
    } else if(strstr(msg,"register") > 0) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged > 0) 
            return "*Sei già loggato. Non puoi registrarti*";
        int free_index = get_free_user_index();
        if(free_index == -1) {
          return "*Non puoi più iscriverti*";
        }
        char *username = calloc(64,sizeof(char));
        char *password = calloc(64,sizeof(char));
        char *found = malloc(sizeof(msg)+1);
        int k=0;
        while( (found = strsep(&msg,"-")) != NULL ) {           //arrivano in questo formato dal client
             if(k==1) username = found;
             if(k==2) password = found;
             k++;
        }
        free(found);
        return register_user(username, password);
    } else if(strstr(msg,"login") > 0) {
       int isLogged = check_loggedUser(userIndex);
        if(isLogged > 0) 
            return "*Sei già loggato.*";
        char *username = calloc(64,sizeof(char));
        char *password = calloc(64,sizeof(char));
        char *found = malloc(sizeof(msg)+1);
        int k=0;
        while( (found = strsep(&msg,"-")) != NULL ) {
             if(k==1) username = found;
             if(k==2) password = found;
             k++;
        }
        free(found);
        return login_user((char *) username,(char *) password);
    } else if(strcmp(msg, "home") == 0) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged < 1) return "*Devi eseguire il login*";
        return build_home(userIndex);
    } else if(strstr(msg, "cip") > 0) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged < 1) return "*Devi eseguire il login*";
        msg = strtok(msg,"-");
        char * cip = calloc(512,sizeof(char));
        cip = strtok(NULL,"-");
        return manage_cip(cip,userIndex);
    } else if(strstr(msg, "follow") != NULL) {
        int isLogged = check_loggedUser(userIndex);
        if(isLogged < 1) return "*Devi eseguire il login*";
        return execute_follow(msg,userIndex);
    } else {
        return "*comando sconosciuto, riprovare (digita help per aiuto)*";
    }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                 GESTIONE SERVER                                                                              //
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

static int init_server(int myport){
    struct sockaddr_in my_addr;
    int fd;

    memset(&my_addr, 0, sizeof(my_addr));
    my_addr.sin_family = AF_INET;
    my_addr.sin_port = htons(myport);
    my_addr.sin_addr.s_addr = INADDR_ANY; /* accept from any interface */

    fd = socket (AF_INET, SOCK_STREAM, 0);

    if (bind(fd, (struct sockaddr*)&my_addr, sizeof(my_addr)) < 0) {
        perror("bind()");
        exit(-1);
    }

    if (listen(fd, 10) < 0) {
        perror("listen()");
        exit(-1);
    }

    printf ("Server listening on port %d \n", myport);
    return fd ;
}

/* I/O for a single client request. */
static void serve_request(int cfd, int index){
    char msg[BUFSIZE];
    int dim, ret;

    ret = recv(cfd, (void*)&dim, sizeof(dim), MSG_WAITALL);
    if (ret < 0 || ret < sizeof(dim)) {
        perror("recv(len)");
        exit(-1);
    }
    dim = ntohl(dim);

    memset(msg, '\0', sizeof(msg)); /* set string terminator everywhere */
    ret = recv(cfd, (void*) msg, dim, MSG_WAITALL);
    if (ret < 0 || ret < dim) {
        perror("recv(msg)");
        exit(-1);
    }
    
    printf("Echoing back message: %s\n", msg);
    
    char* response = manage_response(msg,index);
    
    dim = htonl(dim);
    ret = send(cfd, (void *) &dim, sizeof(dim), 0);
    if(ret < 0 || ret < sizeof(dim)) {
        perror("send(len)");
        exit(-1);
    }
    ret = send(cfd, response, strlen(response), 0);
    if(ret < 0 || ret < strlen(response)) {
        perror("send(response)");
        exit(-1);
    }
    
    close(cfd);
}

/* Thread body for the request handlers. Wait for a signal from the main
 * thread, collect the client file descriptor and serve the request.
 * Signal the main thread when the request has been finished. */
static void * handler_body(void *idx){
    int index = *((int*)idx);
    int cfd;

    free(idx);

    for (;;) {
        /* Wait for a request assigned to us by the main thread. */
        sem_wait(&evsem[index]);
        printf ("Thread %d take charge of a request\n", index);
        pthread_mutex_lock(&glock);
        cfd = fds[index];
        pthread_mutex_unlock(&glock);

        /* Serve the request. */
        serve_request(cfd,index);
        printf ("Thread %d served a request\n", index);

        /* Tell the main thread that I am free now */
        pthread_mutex_lock(&glock);
        busy[index] = 0;
        pthread_mutex_unlock(&glock);
        sem_post(&free_threads);
    }

    pthread_exit(NULL);
}

int main(int argc, char* argv []){
    struct sockaddr_in c_add;
    socklen_t addrlen;
    int lfd, cfd;
    int myport;
    int i;
    
    if (argc < 2) {
        printf("usage: server <port>\n");
        exit(-1);
    }
    myport = atoi(argv[1]);
    lfd = init_server(myport);
    
    pthread_mutex_init(&glock, 0);
    
    pthread_mutexattr_init(&attribute);
    pthread_mutexattr_settype(&attribute, PTHREAD_MUTEX_RECURSIVE);
    pthread_mutex_init(&reg, &attribute);
    pthread_mutex_init(&log, &attribute);
    pthread_mutex_init(&cip, &attribute);
    

    /* Init free_threads to NUM_THREADS, as initially all the threads
     * in the pool are free. */
    sem_init(&free_threads, 0, NUM_THREADS);
    for (i = 0; i < NUM_THREADS; i++) {
        int *idx = malloc(sizeof(*idx));

        if (!idx) {
            printf("Error: out of memory\n");
            exit(-1);
        }
        *idx = i;
        busy[i] = 0; /* thread #i is initially free */
        sem_init(&evsem[i], 0, 0); /* event semaphore is initialized to 0 */
        pthread_create(&tid[i], 0, handler_body, (void *)idx);
    }

    for (;;) {
        /* Wait for a free thread. */
        sem_wait(&free_threads);

        /* Accept the next connection. */
        addrlen = sizeof(c_add);
        cfd = accept(lfd, (struct sockaddr*)&c_add, &addrlen);
        if (cfd < 0) {
            perror("accept()");
            exit(-1);
        }
        /* Look for a free thread, scanning the busy map. */
        pthread_mutex_lock(&glock);
        
        for (i = 0; i < NUM_THREADS; i++) {
            if (!busy[i]) {
                /* found one */
                break;
            }
        }
        assert(i < NUM_THREADS);
        fds[i] = cfd; /* pass the file descriptor for the connection socket */
        busy[i] = 1; /* mark the selected thread as busy */
        pthread_mutex_unlock(&glock);
        sem_post(&evsem[i]); /* wake up the selected thread */
    }

    return 0;
}
