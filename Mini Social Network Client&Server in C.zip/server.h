#ifndef SERVER_H_
#define SERVER_H_

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <assert.h>
#include <semaphore.h>
#include <time.h>
#include <crypt.h>

#define BUFSIZE         6000
#define NUM_THREADS     2   	/* num of threads in the pool */
#define NUM_CIP         100   
#define NUM_USERS       10      
#define NUM_CHARACTERS  280
#define NUM_HASHTAGS    100


struct cip {
    int  time;
    char timeLabel[20];
    char text[NUM_CHARACTERS];
    char username[32];
};

struct hashtags {
    int  time;//
    char timeLabel[20];//
	char text[NUM_CHARACTERS];
	int counter;
    int id;
};


static char * build_home(int );                         //FUNZIONI PER L'UTENTE
static char * register_user(char * , char * );          //FUNZIONI PER L'UTENTE
static char * login_user(char * , char * );             //FUNZIONI PER L'UTENTE
static char * execute_follow(char * msg, int );         //FUNZIONI PER L'UTENTE
static char* print_help();                              //FUNZIONI PER L'UTENTE
static char char_for_salt();            
static void create_salt(char []); 
static int get_free_hash_index(int );
static int get_free_user_index();
static int get_user_index(char * );
static int get_free_follower_index(int );
static int get_free_cip_index(int );
static int valueinarray(int , int []);
static void init_follow_array(int );
static void init_hash_struct_id(int );
static void clean_userData(int );
static int is_valid(int , int );
static int get_hashtag(char **, char [], size_t );
static void extract_hashtag(struct cip, int );
static char* manage_cip(char* ,int );
static char* manage_response(char* ,int );
static int init_server(int );
static void serve_request(int , int );
static void * handler_body(void *);


#endif /*SERVER_H_*/
